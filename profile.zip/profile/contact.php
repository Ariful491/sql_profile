<?php
require  "vendor/autoload.php";
use App\classes\Font;
$public = new Font();

$queryResult=$public->View_category();
$result='';
if (isset($_POST['btn'])){
    $result=$public->messages();
}

?>



<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="assets/public/img/favicon.png" type="image/png">
    <title>Ariful Hoque Portfolio</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/public/css/bootstrap.css">
    <link rel="stylesheet" href="assets/public/vendors/linericon/style.css">
    <link rel="stylesheet" href="assets/public/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/public/vendors/owl-carousel/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/public/css/magnific-popup.css">
    <link rel="stylesheet" href="assets/public/vendors/nice-select/css/nice-select.css">
    <!-- main css -->
    <link rel="stylesheet" href="assets/public/css/style.css">
</head>

<body>

<?php
include "pub_include/navbar.php";
?>

<!--================ Start Banner Area =================-->
<section class="banner_area">
    <div class="banner_inner d-flex align-items-center">
        <div class="container">
            <div class="banner_content text-center">
                <h2>Contact With Me </h2>
                <div class="page_link">

                </div>
            </div>
        </div>
    </div>
</section>
<!--================ End Banner Area =================-->

<!--================Contact Area =================-->
<section class="contact_area section_gap">
    <div class="container">
        <div class="row">
            <div class="col-lg-3">
                <div class="contact_info">
                    <div class="info_item">
                        <i class="lnr lnr-home"></i>
                        <h6>Dhaka ,Bangladesh</h6>
                        <p>kamrangrchar</p>
                    </div>
                    <div class="info_item">
                        <i class="lnr lnr-phone-handset"></i>
                        <h6><a href="#">01995131244</a></h6>
                        <p>Every day 10am to 5pm   </p>
                    </div>
                    <div class="info_item">
                        <i class="lnr lnr-envelope"></i>
                        <h6><a href="#">arifulhoque091@gmail.com</a></h6>
                        <p>Send us your query anytime!</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-9">
                <?php if($result){?>
                    <div class="alert alert-warning alert-dismissible fade show" role="alert">
                        <strong><?php echo $result; ?></strong>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php }?>
                <form class="row contact_form" action="" method="post" >
                    <div class="col-md-6">
                        <div class="form-group">
                            <input type="text" class="form-control" required id="name" name="name" placeholder="Enter your name">
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" required id="name" name="phone" placeholder="Enter your valid phone">
                        </div>
                        <div class="form-group">
                            <input type="email" class="form-control" required id="email" name="address" placeholder="Enter valid email address">
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" required id="subject" name="subject" placeholder="Enter Subject">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <textarea class="form-control" name="message" required id="message" rows="1" placeholder="Enter Message"></textarea>
                        </div>
                        <div class="form-group">

                                <p >N.B <i>Must use valid Phone number and email Address otherwise The message shall not reach me.</i></p>


                        </div>
                    </div>
                    <div class="col-md-12 text-right">
                        <button type="submit" value="submit" class="primary_btn" name="btn">
                            <span>Send Message</span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
        <div class="mt-5">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d58452.79896800747!2d90.33617519738974!3d23.700980860987226!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755becdc844b463%3A0xeb269723f06c3add!2sKalindi!5e0!3m2!1sen!2sbd!4v1581160533645!5m2!1sen!2sbd" width="100%" height="500" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
        </div>

    </div>
</section>
<!--================Contact Area =================-->

<?php include "pub_include/brand_area.php";
?>


<?php include "pub_include/portfolio.php";
?>



<?php include "pub_include/testimonial.php";
?>


<?php include "pub_include/footer_area.php";
?>

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="assets/public/js/jquery-3.2.1.min.js"></script>
<script src="assets/public/js/popper.js"></script>
<script src="assets/public/js/bootstrap.min.js"></script>
<script src="assets/public/js/stellar.js"></script>
<script src="assets/public/js/jquery.magnific-popup.min.js"></script>
<script src="assets/public/vendors/nice-select/js/jquery.nice-select.min.js"></script>
<script src="assets/public/vendors/isotope/imagesloaded.pkgd.min.js"></script>
<script src="assets/public/vendors/isotope/isotope-min.js"></script>
<script src="assets/public/vendors/owl-carousel/owl.carousel.min.js"></script>
<script src="assets/public/js/jquery.ajaxchimp.min.js"></script>
<script src="assets/public/js/mail-script.js"></script>
<!--gmaps Js-->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCjCGmQ0Uq4exrzdcL6rvxywDDOvfAu6eE"></script>
<script src="assets/public/js/gmaps.min.js"></script>
<script src="assets/public/js/theme.js"></script>
</body>

</html>