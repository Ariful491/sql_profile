<?php
session_start();
require "../vendor/autoload.php";
use App\classes\Login;
$login=new Login();
if($_SESSION['id']==null){
    header('location:login.php');
}
if (isset($_GET['logout'])){
    $login->logoutAdmin();
}
use App\classes\Messeages;
$messages = new Messeages();
$queryResult=$messages->view_messages();

if (isset($_GET['delete'])){
    $messages->delete_message($_GET['id']);
}
$result='';
if (isset($_GET['message'])){
    $result=$_GET['message'];
}




?>
<html>
<head>
    <title>AR || Profile</title>
    <link  rel="stylesheet" href="../assets/css/bootstrap.min.css"   >
    <link rel="stylesheet" href="../assets/css/style5.css">
</head>
<body>

<div class="wrapper">

    <?php include "include/nav.php" ?>
    <div id="content">

        <?php include "include/topbar.php" ?>

        <div class="container">
            <div class="row">
                <div class="offset-1 col-md-10">

                    <?php if($result){?>
                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                            <strong><?php echo $result; ?></strong>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php }?>

                    <table class="table">
                        <thead class="thead-light table-bordered table-hover">
                        <tr>
                            <th scope="col">SL No.</th>
                            <th scope="col">Name</th>
                            <th scope="col">Phone Number</th>
                            <th scope="col">Email</th>
                            <th scope="col">Subject</th>
                            <th scope="col">Message</th>
                            <th scope="col">Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php

                        while ($data = mysqli_fetch_assoc($queryResult)){
                        ?>

                        <tr>
                            <th scope="row">1</th>
                            <td><?php echo $data['name']?></td>
                            <td><?php echo $data['phone']?></td>
                            <td><?php echo $data['address']?></td>
                            <td><?php echo $data['subject']?></td>
                            <td><?php echo $data['message']?></td>
                            <td>
                               <a href="?delete=status&id=<?php echo $data['id'] ?>">delete</a>
                            </td>
                        </tr>
                        <?php } ?>


                        </tbody>
                    </table>

                </div>
            </div>
        </div>

    </div>





</div>

<script src="../assets/js/jquery-3.4.1.min.js"></script>
<script src="../assets/js/popper.min.js"></script>
<script src="../assets/js/bootstrap.min.js"></script>

<script type="text/javascript">
    $(document).ready(function () {
        $('#sidebarCollapse').on('click', function () {
            $('#sidebar').toggleClass('active');
            $(this).toggleClass('active');
        });
    });

</script>
</body>
</html>
