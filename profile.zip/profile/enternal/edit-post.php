<?php
session_start();
require "../vendor/autoload.php";
use App\classes\Login;
$login=new Login();
if($_SESSION['id']==null){
    header('location:login.php');
}
if (isset($_GET['logout'])){
    $login->logoutAdmin();
}
use App\classes\Post;
$post= new Post();
$queryResult=$post->getPostById($_GET['id']);
$data=mysqli_fetch_assoc($queryResult);

$queryResult1=$post->viewCategory();
if (isset($_POST['btn'])){
  $result = $post->updatePost();
}




?>
<html>
<head>
    <title>AR || Profile</title>
    <link  rel="stylesheet" href="../assets/css/bootstrap.min.css"   >
    <link rel="stylesheet" href="../assets/css/style5.css">
    <script>
        document.forms['postEdit'].elements['cat_id'].value="<?php echo $data['cat_id'] ?>
        document.forms['postEdit'].elements['pub_status'].value="<?php echo $data['pub_status'] ?>"
    </script>
</head>
<body>

<div class="wrapper">

    <?php include "include/nav.php" ?>
    <div id="content">
        <?php include "include/topbar.php" ?>
        <div class="container">
            <div class="row">
                <div class="offset-1  col-md-9">
                    <div class="text-white">
                        <?php if($result){?>
                            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                <strong><?php echo $result; ?></strong>
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        <?php }?>
                    <div class="card-header bg-primary text-center ">
                            <h3 class=" font-weight-bolder" >Edit Post</h3>
                        </div>

                        <form action="" method="post" enctype="multipart/form-data"  id="postEdit">
                            <div class="card-body bg-dark">
                                <div class="form-group">
                                    <label > Category Name<span class="text-danger">*</span>:-</label>  </div>
                                   <div class="form-group m-md-5">
                                    <select class="form-control" name="cat_id">
                                        <?php while($result=mysqli_fetch_assoc($queryResult1)){ ?>
                                        <option value="<?php echo $result['id'] ?>"><?php echo $result['cat_nam'] ?></option>
                                        <?php } ?>
                                    </select>
                                </div>


                                <div class="form-group">
                                    <label> Post Title<span class="text-danger">*</span>:-</label>
                                    <input type="text" class="form-control"  name="post_title" value="<?php echo $data['post_title']?>">
                                    <input type="hidden" class="form-control"  name="id" value="<?php echo $data['id']?>">
                                </div>
                                <div class="form-group">
                                    <label> Post short Description<span class="text-danger">*</span>:-</label>
                                    <textarea type="text" class="form-control" name="post_short_desc"><?php echo $data['post_short_desc']?></textarea>
                                </div>
                                <div class="form-group">
                                    <label>Post long Description<span class="text-danger">*</span>:-</label>
                                    <textarea type="text" class="form-control" rows="3" name="post_long_desc"><?php echo $data['post_long_desc']?></textarea>
                                </div>

                                <div class="form-group">
                                    <label>Previous  Image</label>
                                    <img class="form-control-file" src="<?php  echo $data['image_upload']?>" height="500px">
                                </div>
                                <div class="form-group">
                                    <label>Upload Image</label>
                                    <input type="file" class="form-control-file"  name="image_upload">
                                </div>

                                <div class="form-group">
                                    <label >Publication Status<span class="text-danger">*</span>:-</label>  </div>
                                <div class="form-group">
                                    <select class="form-control " name="pub_status">
                                        <option value="1">Publish</option>
                                        <option value="0">Unpublished</option>
                                    </select>
                                </div>
                            </div>
                            <div class="card-footer bg-primary">
                                <button type="submit" class="btn btn-block btn-primary" name="btn" >UpDate Category</button>
                            </div>

                        </form>
                    </div> </div></div>
        </div>





    </div>
</div>

<script src="../assets/js/jquery-3.4.1.min.js"></script>
<script src="../assets/js/popper.min.js"></script>
<script src="../assets/js/bootstrap.min.js"></script>


<script type="text/javascript">


    $(document).ready(function () {
        $('#sidebarCollapse').on('click', function () {
            $('#sidebar').toggleClass('active');
            $(this).toggleClass('active');
        });
    });



</script>

</body>
</html>


