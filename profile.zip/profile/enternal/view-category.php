<?php
session_start();
require "../vendor/autoload.php";
use App\classes\Login;
$login=new Login();
if($_SESSION['id']==null){
    header('location:login.php');
}
if (isset($_GET['logout'])){
    $login->logoutAdmin();
}
use App\classes\Category;
$category = new Category();
$queryResult=$category->ViewCategory();
$result='';
if (isset($_GET['message'])){
    $result=$_GET['message'];
}
if (isset($_GET['delete'])){
    $category->deleteCategory($_GET['id']);
}
if(isset($_POST['btn'])){
    $queryResult =$category->searchingCategory();
}

?>
<html>
<head>
    <title>AR || Profile</title>
    <link  rel="stylesheet" href="../assets/css/bootstrap.min.css"   >
    <link rel="stylesheet" href="../assets/css/style5.css">
</head>
<body>

<div class="wrapper">

    <?php include "include/nav.php" ?>
    <div id="content">

        <?php include "include/topbar.php" ?>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <form action="" method="post">
                        <div class="form-group">
                            <input type="text" placeholder="Search......" name="search" class="form-control">
                            <button type="submit" class="offset-11"  name="btn">Search</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <?php if($result){?>
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <strong><?php echo $result; ?></strong>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php }?>
            <table class="table  table-success table-hover table-bordered">
                <thead>
                <tr>
                    <th scope="col">Sl No</th>
                    <th scope="col">Category Name</th>
                    <th scope="col">Category Description</th>
                    <th scope="col">Publication Status</th>
                    <th scope="col">Action</th>
                </tr>
                </thead>
                <tbody>
                <?php
                $i='';
                while ($data=mysqli_fetch_assoc($queryResult)){
                    ?>
                <tr>
                    <th scope="row"><?php echo ++$i; ?></th>
                    <td><?php echo $data['cat_nam'] ?></td>
                    <td><?php echo $data['cat_desc'] ?></td>
                    <td><?php echo $data['pub_status']==1?'Published':'UnPublished' ?></td>
                    <td>
                        <a href="edit-category.php?id=<?php echo $data['id'];?>">edit</a>||
                        <a href="?delete=true&id=<?php echo $data['id']?>">delete</a>
                    </td>
                </tr>
                <?php } ?>
                </tbody>
            </table>

        </div>
    </div>
</div>

    </div>
</div>

<script src="../assets/js/jquery-3.4.1.min.js"></script>
<script src="../assets/js/popper.min.js"></script>
<script src="../assets/js/bootstrap.min.js"></script>

<script type="text/javascript">
    $(document).ready(function () {
        $('#sidebarCollapse').on('click', function () {
            $('#sidebar').toggleClass('active');
            $(this).toggleClass('active');
        });
    });

</script>
</body>
</html>
