<?php
session_start();
require "../vendor/autoload.php";
use App\classes\Login;
$login=new Login();
if($_SESSION['id']==null){
    header('location:login.php');
}
if (isset($_GET['logout'])){
 $login->logoutAdmin();
}
?>
<html>
<head>
    <title>AR || Profile</title>
    <link  rel="stylesheet" href="../assets/css/bootstrap.min.css"   >
    <link rel="stylesheet" href="../assets/css/style5.css">
</head>
<body>

<div class="wrapper">

<?php include "include/nav.php" ?>
<div id="content">

<?php include "include/topbar.php" ?>

</div>





</div>

<script src="../assets/js/jquery-3.4.1.min.js"></script>
<script src="../assets/js/popper.min.js"></script>
<script src="../assets/js/bootstrap.min.js"></script>

<script type="text/javascript">
        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
                $(this).toggleClass('active');
            });
        });

</script>
</body>
</html>
