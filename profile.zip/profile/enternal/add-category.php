<?php
session_start();
require "../vendor/autoload.php";
use App\classes\Login;
$login=new Login();
if($_SESSION['id']==null){
    header('location:login.php');
}
if (isset($_GET['logout'])){
    $login->logoutAdmin();
}
use App\classes\Category;
$category= new Category();
$result='';
if(isset($_POST['btn'])){
    $result=$category->addCategory();
}








?>
<html>
<head>
    <title>AR || Profile</title>
    <link  rel="stylesheet" href="../assets/css/bootstrap.min.css"   >
    <link rel="stylesheet" href="../assets/css/style5.css">
</head>
<body>

<div class="wrapper">
    <?php include "include/nav.php" ?>
    <div id="content">
      <?php include "include/topbar.php" ?>

        <div class="container">
            <div class="row">
                <div class="offset-2 col-md-6">
                    <div class="text-white">
                       <?php if($result){?>
                           <div class="alert alert-warning alert-dismissible fade show" role="alert">
                               <strong><?php echo $result; ?></strong>
                               <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                   <span aria-hidden="true">&times;</span>
                               </button>
                           </div>
                       <?php }?>
                    <div class="card-header bg-primary text-center ">
                        <h3 class=" font-weight-bolder" >Add Category</h3>
                    </div>

                        <form action="" method="post">
                            <div class="card-body bg-dark">
                            <div class="form-group">
                                <label>Enter Your Category Name <sub>[N.B:letter must be lowercase]</sub><span class="text-danger">*</span>:-</label>
                                <input type="text" class="form-control"  name="cat_nam"  >
                            </div>
                            <div class="form-group">
                                <label>Enter Your Category Description<span class="text-danger">*</span>:-</label>
                                <textarea type="text" class="form-control" name="cat_desc"> </textarea>
                            </div>
                                <div class="form-group">
                                    <label >Publication Status<span class="text-danger">*</span>:-</label>  </div>
                                <div class="form-group">
                                    <select class="form-control " name="pub_status">
                                        <option >---Select Option---</option>
                                        <option value="1">Publish</option>
                                        <option value="0">Unpublished</option>
                                    </select>
                                </div>
                            </div>
                            <div class="card-footer bg-primary">
                                <button type="submit" class="btn btn-block btn-primary" name="btn" >Add Category</button>
                            </div>

                        </form>
                    </div> </div>
                </div>
            </div>
        </div>

    </div>






<script src="../assets/js/jquery-3.4.1.min.js"></script>
<script src="../assets/js/popper.min.js"></script>
<script src="../assets/js/bootstrap.min.js"></script>

<script type="text/javascript">
    $(document).ready(function () {
        $('#sidebarCollapse').on('click', function () {
            $('#sidebar').toggleClass('active');
            $(this).toggleClass('active');
        });
    });

</script>
</body>
</html>
