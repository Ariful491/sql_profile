<?php
session_start();
require "../vendor/autoload.php";
use App\classes\Login;
$login=new Login();
if($_SESSION['id']==null){
    header('location:login.php');
}
if (isset($_GET['logout'])){
    $login->logoutAdmin();
}
use App\classes\Post;
$post= new Post();
$queryResult=$post->viewCategory();

$result='';
if (isset($_POST['btn'])){
    $result=$post->savePost();
}

?>
<html>
<head>
    <title>AR || Profile</title>
    <link  rel="stylesheet" href="../assets/css/bootstrap.min.css"   >
    <link rel="stylesheet" href="../assets/css/style5.css">
</head>
<body>

<div class="wrapper">
    <?php include "include/nav.php" ?>
    <div id="content">
        <?php include "include/topbar.php" ?>
        <div class="container">
            <div class="row">
                <div class="offset-1  col-md-9">
                    <div class="text-white">
                        <?php if($result){?>
                            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                <strong><?php echo $result; ?></strong>
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        <?php }?>
                        <div class="card-header bg-primary text-center ">
                            <h3 class=" font-weight-bolder" >Add Post</h3>
                        </div>

                        <form action="" method="post" enctype="multipart/form-data">
                            <div class="card-body bg-dark">

                                <div class="form-group">
                                    <label >Choice Category Name<span class="text-danger">*</span>:-</label>  </div>
                                <div class="form-group m-md-5">
                                    <select class="form-control" name="cat_id">
                                        <option >---Select Category Name---</option>
                                        <?php while($data=mysqli_fetch_assoc($queryResult)){ ?>
                                        <option value="<?php echo $data ['id']?>" ><?php echo $data['cat_nam'] ?></option>
                                        <?php }?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Enter Your Post Title<span class="text-danger">*</span>:-</label>
                                    <input type="text" class="form-control"  name="post_title">
                                </div>
                                <div class="form-group">
                                    <label>Enter Your Post short Description<span class="text-danger">*</span>:-</label>
                                    <textarea type="text" class="form-control" name="post_short_desc"> </textarea>
                                </div>
                                <div class="form-group">
                                    <label>Enter Your Post long Description<span class="text-danger">*</span>:-</label>
                                    <textarea type="text" class="form-control" rows="3" name="post_long_desc"> </textarea>
                                </div>

                                <div class="form-group">
                                    <label>Upload Image</label>
                                    <input type="file" class="form-control-file"  name="image_upload">
                                </div>

                                <div class="form-group">
                                    <label >Publication Status<span class="text-danger">*</span>:-</label>  </div>
                                <div class="form-group">
                                    <select class="form-control " name="pub_status">
                                        <option >---Select Option---</option>
                                        <option value="1">Publish</option>
                                        <option value="0">Unpublished</option>
                                    </select>
                                </div>
                            </div>
                            <div class="card-footer bg-primary">
                                <button type="submit" class="btn btn-block btn-primary" name="btn" >Add Post</button>
                            </div>

                        </form>
                    </div> </div></div>
            </div>
        </div>

    </div>







<script src="../assets/js/jquery-3.4.1.min.js"></script>
<script src="../assets/js/popper.min.js"></script>
<script src="../assets/js/bootstrap.min.js"></script>

<script type="text/javascript">
    $(document).ready(function () {
        $('#sidebarCollapse').on('click', function () {
            $('#sidebar').toggleClass('active');
            $(this).toggleClass('active');
        });
    });

</script>
</body>
</html>
