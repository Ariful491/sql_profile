<?php
session_start();
require "../vendor/autoload.php";
use App\classes\Login;
$login=new Login();
if($_SESSION['id']==null){
    header('location:login.php');
}
if (isset($_GET['logout'])){
    $login->logoutAdmin();
}
use App\classes\Post;
$post = new Post();
$queryResult=$post->viewPost();
if (isset($_POST['btn'])){
    $queryResult=$post->searchPost();
}
$result='';
if (isset($_GET['delete'])){
   $post->deletePost($_GET['id']);
}


if (isset($_GET['message'])){
    $result=$_GET['message'];
}


?>
<html>
<head>
    <title>AR || Profile</title>
    <link  rel="stylesheet" href="../assets/css/bootstrap.min.css"   >
    <link rel="stylesheet" href="../assets/css/style5.css">
</head>
<body>
<div class="wrapper">
    <?php include "include/nav.php" ?>
    <div id="content">
        <?php include "include/topbar.php" ?>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <form action="" method="post">
                        <div class="form-group">
                            <input type="text" placeholder="Search......" name="search" class="form-control">
                            <button type="submit" class="offset-11"  name="btn">Search</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php if($result){?>
            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                <strong><?php echo $result; ?></strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php }?>

        <table class="table table-bordered table-hover">
            <thead class="thead-light">
            <tr>
                <th scope="col">Sl No.</th>
                <th scope="col">Category Name</th>
                <th scope="col">Post Title</th>
                <th scope="col">Post Short Description</th>
                <th scope="col">Post long Description</th>
                <th scope="col">Image</th>
                <th scope="col">Publication Status</th>
                <th scope="col">Action</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $i='';
            while ($data=mysqli_fetch_assoc($queryResult)){
                ?>
            <tr>
                <th scope="row"><?php echo ++$i;?></th>
                <td  class="text-justify" style="word-break: break-all;"><?php echo $data ['cat_nam']?></td>
                <td  class="text-justify" style="word-break: break-all;"><?php echo $data ['post_title']?></td>
                <td  class="text-justify" style="word-break: break-all;"><?php echo $data ['post_short_desc']?></td>
                <td  class="text-justify" style="word-break: break-all;"><?php echo $data ['post_long_desc']?></td>
                <td  class="text-justify" style="word-break: break-all;"><img src="<?php echo $data['image_upload'] ?>" height="80px"></td>
                <td  class="text-justify" style="word-break: break-all;"><?php echo $data ['pub_status']==1?'Published':'Unpublished'?></td>
                <td  class="text-justify" style="word-break: break-all;">
                <a href="edit-post.php?id=<?php echo $data['id']?>">Edit</a>||<br>
                    <a href="?delete=true&id=<?php echo $data['id']?>" >Delete</a>
                </td>
            </tr>
            <?php } ?>

            </tbody>
        </table>

    </div>

</div>

<script src="../assets/js/jquery-3.4.1.min.js"></script>
<script src="../assets/js/popper.min.js"></script>
<script src="../assets/js/bootstrap.min.js"></script>

<script type="text/javascript">
    $(document).ready(function () {
        $('#sidebarCollapse').on('click', function () {
            $('#sidebar').toggleClass('active');
            $(this).toggleClass('active');
        });
    });

</script>
</body>
</html>

