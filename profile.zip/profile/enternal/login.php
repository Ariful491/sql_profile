<?php
session_start();

if (isset($_SESSION['id'])){
    header('location:index.php');
}
require "../vendor/autoload.php";

use App\classes\Login;
$login = new Login();

if(isset($_POST['btn'])){
      $login->adminLoginCheck();
}


?>

<html>
<head>
    <title>Login form</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>
<body>
<div class="container">
    <div class="row">
        <div class="offset-4 col-md-4 " style="margin-top: 150px;">
            <div class="card">
                <div class="card-header bg-success">
                    <h3 class="text-center font-weight-bolder">Admin Panel</h3>
                </div>
                <div class="card-body">
                    <form action="" method="post">
                      <div class="form-group">
                          <label>Email</label>
                          <input type="email" name="email" required class="form-control">
                      </div>
                        <div class="form-group">
                          <label>password</label>
                          <input type="password" name="password" required class="form-control">
                      </div>
                        <div class="">
                            <button type="submit" class="btn btn-block btn-info font-weight-bold" name="btn" >Log In</button>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>




<script src="../assets/js/jquery-3.4.1.min.js"></script>
<script src="../assets/js/bootstrap.min.js"></script>
</body>
</html>