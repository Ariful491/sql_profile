

    <!-- Sidebar Holder -->
    <nav id="sidebar">
        <div class="sidebar-header">
            <h3>AR Admin</h3>
        </div>

        <ul class=" components">
            <li>
                <a href="#category" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">Category</a>
                <ul class="collapse list-unstyled" id="category">
                    <li>
                        <a href="add-category.php">Add Category</a>
                    </li>
                    <li>
                        <a href="view-category.php">View Category</a>
                    </li>

                </ul>
            </li>
            <li>
                <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">Category wise Post  </a>
                <ul class="collapse list-unstyled" id="pageSubmenu">
                    <li>
                        <a href="add-post.php">Add Post</a>
                    </li>
                    <li>
                        <a href="view-post.php">View Post</a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="view-messages.php">view messages</a>
            </li><li>
                <a href="#">CV</a>
            </li>

        </ul>


    </nav>


