<nav class="navbar navbar-expand-lg navbar-light bg-light mb-0">
    <div class="container-fluid">

        <button type="button" id="sidebarCollapse" class="navbar-btn">
            <span></span>
            <span></span>
            <span></span>
        </button>
        <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <p style="color: white; text-align: center; padding-top: 12px;"><sub>*</sub></p>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent"><ul class="navbar-nav " style="margin-left:80%;">
                <li class="nav-item dropdown ">
                    <a class="nav-link" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <?php echo $_SESSION['name']; ?>
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                        <a class="dropdown-item" href="?logout=true">Log Out</a>
                    </div>
                </li>
            </ul>
        </div>
    </div>

</nav>