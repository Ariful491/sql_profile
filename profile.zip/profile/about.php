<?php
require  "vendor/autoload.php";
use App\classes\Font;
$public = new Font();
$queryResult=$public->View_category();

$result='';
if (isset($_GET['id'])){
    $result=$public->viewById($_GET['id']);
}
$about=mysqli_fetch_assoc($result);

?>



<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="assets/public/img/favicon.png" type="image/png">
    <title>Ariful Hoque Portfolio</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/public/css/bootstrap.css">
    <link rel="stylesheet" href="assets/public/vendors/linericon/style.css">
    <link rel="stylesheet" href="assets/public/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/public/vendors/owl-carousel/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/public/css/magnific-popup.css">
    <link rel="stylesheet" href="assets/public/vendors/nice-select/css/nice-select.css">
    <!-- main css -->
    <link rel="stylesheet" href="assets/public/css/style.css">
</head>

<body>

<?php
include "pub_include/navbar.php";
?>
<!--================ Start Banner Area =================-->
<section class="banner_area">
    <div class="banner_inner d-flex align-items-center">
        <div class="container">
            <div class="banner_content text-center">
                <h2>About Me</h2>
                <div class="page_link">

                </div>
            </div>
        </div>
    </div>
</section>
<!--================ End Banner Area =================-->


<!--================ Start About Us Area =================-->
<section class="about_area section_gap">
    <div class="container">
        <div class="row justify-content-start align-items-center">
            <div class="col-lg-5">
                <div class="about_img">
                    <img class="" src="assets/<?php echo $about['image_upload'] ?>" alt="">
                </div>
            </div>

            <div class="offset-lg-1 col-lg-5">
                <div class="main_title text-left">
                    <h2>let’s <br>
                        <?php  echo $about['post_title'] ?></h2>
                    <p>
                        <?php  echo $about['post_short_desc'] ?>
                    </p>
                    <p>
                        <?php  echo $about['post_long_desc'] ?>
                    </p>
                    <a class="primary_btn" href="#"><span>Download CV</span></a>
                </div>
            </div>
        </div>
    </div>
</section>
<!--================ End About Us Area =================-->

<?php include "pub_include/brand_area.php";
?>


<?php include "pub_include/portfolio.php";
?>



<?php include "pub_include/testimonial.php";
?>


<?php include "pub_include/footer_area.php";
?>

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="assets/public/js/jquery-3.2.1.min.js"></script>
<script src="assets/public/js/popper.js"></script>
<script src="assets/public/js/bootstrap.min.js"></script>
<script src="assets/public/js/stellar.js"></script>
<script src="assets/public/js/jquery.magnific-popup.min.js"></script>
<script src="assets/public/vendors/nice-select/js/jquery.nice-select.min.js"></script>
<script src="assets/public/vendors/isotope/imagesloaded.pkgd.min.js"></script>
<script src="assets/public/vendors/isotope/isotope-min.js"></script>
<script src="assets/public/vendors/owl-carousel/owl.carousel.min.js"></script>
<script src="assets/public/js/jquery.ajaxchimp.min.js"></script>
<script src="assets/public/js/mail-script.js"></script>
<!--gmaps Js-->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCjCGmQ0Uq4exrzdcL6rvxywDDOvfAu6eE"></script>
<script src="assets/public/js/gmaps.min.js"></script>
<script src="assets/public/js/theme.js"></script>
</body>

</html>