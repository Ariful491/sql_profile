<?php
require  "vendor/autoload.php";
use App\classes\Font;
$public = new Font();

$queryResult=$public->View_category();
$result='';

if (isset($_GET['id'])){
    $result=$public->viewById($_GET['id']);
}
$data=mysqli_fetch_assoc($result);



?>



<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="assets/public/img/favicon.png" type="image/png">
    <title>Ariful Hoque Portfolio</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/public/css/bootstrap.css">
    <link rel="stylesheet" href="assets/public/vendors/linericon/style.css">
    <link rel="stylesheet" href="assets/public/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/public/vendors/owl-carousel/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/public/css/magnific-popup.css">
    <link rel="stylesheet" href="assets/public/vendors/nice-select/css/nice-select.css">
    <!-- main css -->
    <link rel="stylesheet" href="assets/public/css/style.css">
</head>

<body>

<?php
include "pub_include/navbar.php";
?>

<!--================ Start Home Banner Area =================-->
<section class="home_banner_area">
    <div class="banner_inner">
        <div class="container">
            <div class="row">
                <div class="col-lg-7">
                    <div class="banner_content">
                        <h3 class="text-uppercase"><?php echo $data['post_title'] ?></h3>
                        <h1 class="text-uppercase"><?php echo $data['post_short_desc'] ?></h1>
                        <h5 class="text-uppercase"><?php echo $data['post_long_desc'] ?></h5>
                        <div class="d-flex align-items-center">

                            <a class="primary_btn"  href="contact.php"><span>Contact</span></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5">
                    <div class="home_right_img">
                        <img class="" src="assets/<?php echo $data['image_upload'] ?>" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--================ End Home Banner Area =================-->


<?php include "pub_include/brand_area.php";
?>


<?php include "pub_include/portfolio.php";
?>



<?php include "pub_include/testimonial.php";
?>


<?php include "pub_include/footer_area.php";
?>

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="assets/public/js/jquery-3.2.1.min.js"></script>
<script src="assets/public/js/popper.js"></script>
<script src="assets/public/js/bootstrap.min.js"></script>
<script src="assets/public/js/stellar.js"></script>
<script src="assets/public/js/jquery.magnific-popup.min.js"></script>
<script src="assets/public/vendors/nice-select/js/jquery.nice-select.min.js"></script>
<script src="assets/public/vendors/isotope/imagesloaded.pkgd.min.js"></script>
<script src="assets/public/vendors/isotope/isotope-min.js"></script>
<script src="assets/public/vendors/owl-carousel/owl.carousel.min.js"></script>
<script src="assets/public/js/jquery.ajaxchimp.min.js"></script>
<script src="assets/public/js/mail-script.js"></script>
<!--gmaps Js-->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCjCGmQ0Uq4exrzdcL6rvxywDDOvfAu6eE"></script>
<script src="assets/public/js/gmaps.min.js"></script>
<script src="assets/public/js/theme.js"></script>
</body>

</html>