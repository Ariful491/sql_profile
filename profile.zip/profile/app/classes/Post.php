<?php


namespace App\classes;
use App\classes\Database;
class Post
{
    public function viewCategory(){
        $sql= "SELECT * FROM categories WHERE pub_status=1";
        if($queryResult=mysqli_query(Database::dbConnection(),$sql)){
            return $queryResult;
        }
        else{
            die("Query Error".mysqli_error(Database::dbConnection()));
        }
    }
    public function savePost(){
        $cat_id = $_POST['cat_id'];
        $post_title=$_POST['post_title'];
        $post_short_desc= $_POST['post_short_desc'];
        $post_long_desc=$_POST['post_long_desc'];
        $pub_status=$_POST['pub_status'];

        $directory = "../assets/uploaded_images/";
        $imageName = $_FILES['image_upload']['name'];
        $imageUrl = $directory.$imageName;
        $fileType = pathinfo($imageName,PATHINFO_EXTENSION);
        $check = getimagesize($_FILES['image_upload']['tmp_name']);

        if($check){
            if(file_exists($imageUrl)){
                die('file already exists.please uploaded new file');
            }else{
                if($_FILES['image_upload']['size']>2000000){
                    die('image file to large please upload within  2mb');
                }
                else{
                    if ($fileType != 'jpg' && $fileType!= 'png'){
                        die('upload  an image ');
                    }else{
                        move_uploaded_file($_FILES['image_upload']['tmp_name'],$imageUrl);

                        $sql ="INSERT INTO posts(cat_id,post_title,post_short_desc,post_long_desc,image_upload,pub_status)  VALUES ('$cat_id','$post_title','$post_short_desc','$post_long_desc','$imageUrl','$pub_status')";

                        if(mysqli_query(Database::dbConnection(),$sql)){
                            return "Added New Post";
                        } else{
                            die("Query Error".mysqli_error(Database::dbConnection()));
                        }
                    }

                }}}


    }
    public function viewPost(){

        $sql= "SELECT p.*,c.cat_nam FROM posts as p ,categories as c WHERE p.cat_id = c.id";

        if($queryResult=mysqli_query(Database::dbConnection(),$sql)){
           return $queryResult;
        } else{
            die("Query Error".mysqli_error(Database::dbConnection()));
        }
    }
    public function getPostById($id){
        $sql= "SELECT * FROM posts WHERE id = '$id'";
        if($queryResult=mysqli_query(Database::dbConnection(),$sql)){
            return $queryResult;
        } else{
            die("Query Error".mysqli_error(Database::dbConnection()));
        }
    }
    public function updatePost(){
        $imageName = $_FILES['image_upload']['name'];
        if($imageName){
            $sql="SELECT * FROM posts WHERE id='$_POST[id]";
            $queryResult = mysqli_query(Database::dbConnection(),$sql);
//    $data=mysqli_fetch_assoc($queryResult);
            unset( $queryResult['image_upload']);
            $directory = "../assets/uploaded_images/";
            $imageName = $_FILES['image_upload']['name'];
            $imageUrl = $directory.$imageName;
            $fileType = pathinfo($imageName,PATHINFO_EXTENSION);
            $check = getimagesize($_FILES['image_upload']['tmp_name']);

            if($check){
                if(file_exists($imageUrl)){
                    die('file already exists.please uploaded new file');
                }else{
                    if($_FILES['image_upload']['size']>2000000){
                        die('image file to large please upload within  2mb');
                    }
                    else{
                        if ($fileType != 'jpg' && $fileType!= 'png'){
                            die('upload  an image ');
                        }else{
                            move_uploaded_file($_FILES['image_upload']['tmp_name'],$imageUrl);

                            $sql="UPDATE  posts SET cat_id='$_POST[cat_id]',post_title='$_POST[post_title]',post_short_desc='$_POST[post_short_desc]',post_long_desc='$_POST[post_long_desc]',image_upload='$imageUrl',pub_status='$_POST[pub_status]' WHERE id='$_POST[id]'";
                            if(mysqli_query(Database::dbConnection(),$sql)){
                                return "Updated Post";
                            } else{
                                die("Query Error".mysqli_error(Database::dbConnection()));
                            }
                        }

                    }}}


        }else{
            $sql="UPDATE posts SET cat_id='$_POST[cat_id]',post_title='$_POST[post_title]',post_short_desc='$_POST[post_short_desc]',post_long_desc='$_POST[post_long_desc]',pub_status='$_POST[pub_status]' WHERE id='$_POST[id]'";

            if(mysqli_query(Database::dbConnection(),$sql)){
                return "Updated  Post";
            } else{
                die("Query Error".mysqli_error(Database::dbConnection()));
            }
        }
    }
    public function searchPost(){
        $sql="SELECT * FROM posts  WHERE cat_id LIKE '%$_POST[search]%' || post_title LIKE '%$_POST[search]%' || post_short_desc LIKE '%$_POST[search]%' || post_long_desc LIKE '%$_POST[search]%'||pub_status LIKE '%$_POST[search]%'";
        if($queryResult=mysqli_query(Database::dbConnection(),$sql)){
            return $queryResult;
        } else{
            die("Query Error".mysqli_error(Database::dbConnection()));
        }
    }
    public function deletePost($id){
        $sql="DELETE  FROM posts WHERE id='$id'";
        if(mysqli_query(Database::dbConnection(),$sql)){
            header('location:view-post.php?message="Deleted Successfully"');
        } else{
            die("Query Error".mysqli_error(Database::dbConnection()));
        }
    }



}