<?php


namespace App\classes;
use App\classes\Database;

class Messeages
{
 public function view_messages(){
     $sql="SELECT * FROM  visitor_message";


     if($queryResult=mysqli_query(Database::dbConnection(),$sql)){
         return $queryResult;
     } else{
         die("Query Error".mysqli_error(Database::dbConnection()));
     }
 }
 public function delete_message($id){
     $sql="DELETE  FROM visitor_message WHERE id='$id'";

     if(mysqli_query(Database::dbConnection(),$sql)){

        header('location:view-messages.php?message="Deleted Successfully"');

     } else{
         die("Query Error".mysqli_error(Database::dbConnection()));
     }
 }
}