<?php
namespace App\classes;
use App\classes\Database;
class Category
{
 public function addCategory(){
     $cat_name=$_POST['cat_nam'];
     $cat_desc=$_POST['cat_desc'];
     $pub_status=$_POST['pub_status'];
     if(!preg_match("/^[a-z]+$/",$cat_name)){
         return "* only small latter are allowed for category Name";}
     else{
         $sql="INSERT INTO categories(cat_nam,cat_desc,pub_status) VALUE ('$cat_name','$cat_desc','$pub_status')";
         if(mysqli_query(Database::dbConnection(),$sql)){
             Return "Successfully Added Category";
         }else{
             die("query Error".mysqli_error(Database::dbConnection()));
         }
     }


 }
 public function ViewCategory(){
     $sql="SELECT * FROM categories";
     if ($queryResult=mysqli_query(Database::dbConnection(),$sql)){
      return $queryResult;
     }
     else{
         die("Query Error".mysqli_error(Database::dbConnection()));
     }
 }
 public function getAllByCategoryId($id){
     $sql="SELECT * FROM categories WHERE id='$id'";
     if ($queryResult=mysqli_query(Database::dbConnection(),$sql)){
         return $queryResult;
     }
     else{
         die("Query Error".mysqli_error(Database::dbConnection()));
     }

 }
 public function updateCategory(){
     $cat_nam = $_POST['cat_nam'];
     $cat_des = $_POST['cat_desc'];
     $pub_status = $_POST['pub_status'];
     $cat_id=$_POST['id'];
     if(!preg_match("/^[a-z]+$/",$cat_nam)){
         header('location:view-category.php?message="please take Category name only small letter"');
        }
     else{
         $sql= "UPDATE categories SET cat_nam='$cat_nam',cat_desc='$cat_des',pub_status='$pub_status' WHERE id='$cat_id'";
         if ($queryResult=mysqli_query(Database::dbConnection(),$sql)){
             header('location:view-category.php?message="Updated Category successfully"');
         }
         else{
             die("Query Error".mysqli_error(Database::dbConnection()));
         }
     }


 }
 public function deleteCategory($id){
     $sql= "DELETE FROM categories WHERE id='$id'";
     if ($queryResult=mysqli_query(Database::dbConnection(),$sql)){
         header('location:view-category.php?message="Deleted Category successfully"');
     }
     else{
         die("Query Error".mysqli_error(Database::dbConnection()));
     }
 }
 public function searchingCategory(){
     $sql  = "SELECT * FROM categories  WHERE cat_nam LIKE'%$_POST[search]%' || cat_desc LIKE'%$_POST[search]%'";
     if($queryResult=mysqli_query(Database::dbConnection(),$sql)){

         return $queryResult;

     } else{
         die("query error".mysqli_error(Database::dbConnection()));
     }
 }
}