<?php

namespace App\classes;

use App\classes\Database;
class Login
{
    public function adminLoginCheck()
    {
        $email = $_POST['email'];
        $password = md5($_POST['password']);

        $sql = "SELECT * FROM user WHERE email='$email' AND password='$password'";

        if ($queryResult = mysqli_query(Database::dbConnection(), $sql)) {

            $data = mysqli_fetch_assoc($queryResult);
            if ($data) {
                session_start();
                $_SESSION['id']=$data['id'];
                $_SESSION['name']=$data['name'];
                header('location:index.php');
            } else {
                header('location:login.php');
            }
        }
            else{
                die("Query problem ".mysqli_error(Database::dbConnection()));
            }

        }

        public function logoutAdmin(){
         unset($_SESSION['id']);
         unset($_SESSION['name']);
         header('location:login.php');
        }

}