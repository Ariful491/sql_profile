<?php


namespace App\classes;
use App\classes\Database;

class Font
{
    public function View_category(){


        $sql="SELECT * FROM categories WHERE pub_status=1";
        if($queryResult=mysqli_query(Database::dbConnection(),$sql)){
            return $queryResult;
        }
        else{
            die("Query Error".mysqli_error(mysqli_query(Database::dbConnection())));
        }
    }

    public function viewById($id){
     $sql = "SELECT * FROM posts WHERE cat_id='$id'";

        if($queryResult=mysqli_query(Database::dbConnection(),$sql)){
           return $queryResult;
        }
        else{
            die("Query Error".mysqli_error(Database::dbConnection()));
        }
    }

    public function messages(){

        $sql="INSERT INTO visitor_message (name,phone,address,subject,message) VALUE ('$_POST[name]','$_POST[phone]','$_POST[address]','$_POST[subject]','$_POST[message]')";

        if(mysqli_query(Database::dbConnection(),$sql)){
            return "message Send Successfully";
        }
        else{
            die("Query Error".mysqli_error(Database::dbConnection()));
        }
    }


}