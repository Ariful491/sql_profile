
<?php
require  "vendor/autoload.php";
use App\classes\Font;
$public = new Font();

$queryResult=$public->View_category();

$result='';
if (isset($_GET['id'])){
    $result=$public->viewById($_GET['id']);
}


?>






<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="assets/public/img/favicon.png" type="image/png">
    <title>Ariful Hoque Portfolio</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/public/css/bootstrap.css">
    <link rel="stylesheet" href="assets/public/vendors/linericon/style.css">
    <link rel="stylesheet" href="assets/public/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/public/vendors/owl-carousel/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/public/css/magnific-popup.css">
    <link rel="stylesheet" href="assets/public/vendors/nice-select/css/nice-select.css">
    <!-- main css -->
    <link rel="stylesheet" href="assets/public/css/style.css">
</head>

<body>

<?php
include "pub_include/navbar.php";
?>
<!--================ Start Banner Area =================-->
<section class="banner_area">
    <div class="banner_inner d-flex align-items-center">
        <div class="container">
            <div class="banner_content text-center">
                <h2>Services</h2>
                <div class="page_link">
                </div>
            </div>
        </div>
    </div>
</section>
<!--================ End Banner Area =================-->


<!--================ Start Features Area =================-->
<section class="features_area section_gap_top">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8 text-center">
                <div class="main_title">
                    <h2>service offers </h2>
                    <p>
                        Is give may shall likeness made yielding spirit a itself togeth created
                        after sea <br> is in beast beginning signs open god you're gathering ithe
                    </p>
                </div>
            </div>
        </div>
        <div class="row feature_inner">
            <?php while($service=mysqli_fetch_assoc($result)){ ?>
            <div class="col-lg-3 col-md-6">
                <div class="feature_item">
                    <img src="assets/<?php echo $service['image_upload']?>" height="120" alt="">
                    <h4><?php echo $service['post_title']?></h4>
                    <p><?php echo $service['post_short_desc']?></p>
                    <p><?php echo $service['post_long_desc']?></p>
                </div>
            </div>
            <?php }?>
        </div>
    </div>
</section>
<!--================ End Features Area =================-->





<?php include "pub_include/brand_area.php";
?>


<?php include "pub_include/portfolio.php";
?>



<?php include "pub_include/testimonial.php";
?>


<?php include "pub_include/footer_area.php";
?>

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="assets/public/js/jquery-3.2.1.min.js"></script>
<script src="assets/public/js/popper.js"></script>
<script src="assets/public/js/bootstrap.min.js"></script>
<script src="assets/public/js/stellar.js"></script>
<script src="assets/public/js/jquery.magnific-popup.min.js"></script>
<script src="assets/public/vendors/nice-select/js/jquery.nice-select.min.js"></script>
<script src="assets/public/vendors/isotope/imagesloaded.pkgd.min.js"></script>
<script src="assets/public/vendors/isotope/isotope-min.js"></script>
<script src="assets/public/vendors/owl-carousel/owl.carousel.min.js"></script>
<script src="assets/public/js/jquery.ajaxchimp.min.js"></script>
<script src="assets/public/js/mail-script.js"></script>
<!--gmaps Js-->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCjCGmQ0Uq4exrzdcL6rvxywDDOvfAu6eE"></script>
<script src="assets/public/js/gmaps.min.js"></script>
<script src="assets/public/js/theme.js"></script>
</body>

</html>